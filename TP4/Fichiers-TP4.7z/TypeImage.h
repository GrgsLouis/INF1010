//
// Created by Gabriel Bernard
//

#ifndef TP3_TYPE_IMAGE_H
#define TP3_TYPE_IMAGE_H

enum TypeImage {
	NB, Gris, Couleurs, Negatif
};

#endif // TP3_TYPE_IMAGE_H